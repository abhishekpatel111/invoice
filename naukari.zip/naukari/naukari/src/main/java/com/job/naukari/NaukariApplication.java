package com.job.naukari;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NaukariApplication {

	public static void main(String[] args) {
		SpringApplication.run(NaukariApplication.class, args);
	}

}
