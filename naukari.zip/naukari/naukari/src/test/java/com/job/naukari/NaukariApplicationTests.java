package com.job.naukari;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaukariApplicationTests {

	@Test
	void contextLoads() {
	}

}
